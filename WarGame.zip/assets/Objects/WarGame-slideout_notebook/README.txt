If you would like to participate in making the game, send me an email (mankkisoftware@gmail.com).

WarGame (this is not the final name of the game) is a chess-like war game. 

Charasteristics:
-The game has two players: red player and blue player.
-Both players have 20 pieces (10 soldiers, 6 tanks, 2 radars, 1 missile and 1 airplane)
  -A soldier can move 1 tile. Its health is 1 and its damage is 1.
  -A tank can move 2 tiles. Its health is 2 and its damage is 2.
  -A radar can move 3 (or 4) tiles. Its health is 1 and its damage is 0.
  -A missile cannot move, but it always hits. Its health is 3 and its damage is 3.
  -An airplane can move 5 tiles. Its health is 1 and its damage is 3.
-The red player plays first
-A player can make 3 actions per round (move, shoot etc.).
-The other player's pieces are hidden untill you find them (with your moving range).
-You can hide a piece again by moving it (only stationary pieces remain in the enemy's sight).
-The winner is the one who destroys all enemy pieces.

